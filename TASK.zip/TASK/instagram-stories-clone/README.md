# Instagram Stories Clone

A **simplified Instagram Stories feature** built with **React.js & TypeScript**, allowing users to view, navigate, and close stories.

---

## Features
    **Mobile-only app** (Hidden on desktops)  
    **Horizontally scrollable story list**  
    **Click to open a story**  
    **Double-click right to move to the next story**  
    **Double-click left to move to the previous story**  
    **Auto-advances every 5 seconds**  
    **Close button to exit stories**  
    **End-to-end tested using Jest & React Testing Library**  

---

## Tech Stack
- **Frontend**: React.js (TypeScript)  
- **Styling**: CSS (Responsive Design)  
- **Testing**: Jest & React Testing Library  
- **Package Manager**: npm  

---
### Install Dependencies
```sh
npm install
```
<!-- npm install first after clone to get node module. -->
## 📥 Installation & Setup
### Clone the Repository
```sh
cd instagram-stories-clone
```

### Start the Development Server
```sh
npm start
```
 The app will open at **`http://localhost:3000`**  

---

## Mobile-Only View
This app is **restricted to mobile devices**.  
🔹 On desktops, you will see a message: _"This app is only available on mobile."_  
🔹 Please uncomment the changes in App.tsx, added comments. 


---

## Running Tests
###  Run Jest Tests
```sh
npm test
```
- Ensures stories open, navigate, and close correctly.  
- Tests double-click navigation.  

---

## Deployment
### Deploying to Vercel
1. Install Vercel CLI:
   ```sh
   npm install -g vercel
   ```
2. Deploy the app:
   ```sh
   vercel
   ```
3. Follow the **Vercel URL** provided after deployment.

---

##  Folder Structure
```
instagram-stories/
│── src/
│   │── components/
│   │   │── StoryList.tsx
│   │   │── StoryViewer.tsx
│   │── assets/
│   │   │── story1.jpg
│   │   │── story2.jpg
│   │   │── story3.jpg
│   │── __tests__/
│   │   │── stories.test.tsx  # Jest Tests
│   │── App.tsx
│   │── index.tsx
│   │── styles.css
│── public/
│── package.json
│── README.md
```

---

## How It Works
1. **On Mobile**:  
   - Scroll through stories in a horizontal row.  
   - Click to open a story.  
   - Double-click **right** to go to the next story.  
   - Double-click **left** to go back.  
   - Stories auto-advance after 5 seconds.  
   - Click **close (×)** to return to the main screen.  

2. **On Desktop**:  
   - A message appears: _"This app is only available on mobile."_  

---

## Contributing
1. Fork the repository  
2. Create a new branch:  
   ```sh
   git checkout -b feature-name
   ```
3. Make your changes & commit:  
   ```sh
   git commit -m "Added new feature"
   ```
4. Push your changes:  
   ```sh
   git push origin feature-name
   ```
5. Open a pull request  

---