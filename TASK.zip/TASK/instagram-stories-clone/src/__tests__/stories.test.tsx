import React from "react";
import { render, fireEvent, screen } from "@testing-library/react";
import "@testing-library/jest-dom";
import App from "../App";

describe("Instagram Stories Feature", () => {
  it("should display stories before opening", () => {
    render(<App />);
    const stories = screen.getAllByRole("img");
    expect(stories.length).toBeGreaterThan(0);
    expect(stories[0]).toBeVisible();
  });

  it("should open a story when clicked", () => {
    render(<App />);
    const firstStory = screen.getAllByRole("img")[0];

    fireEvent.click(firstStory);
    expect(screen.getByRole("button", { name: /×/ })).toBeVisible();
    expect(screen.getByAltText("Story")).toBeVisible(); 
  });

  it("should move to the next story on double-clicking right side", () => {
    render(<App />);
    fireEvent.click(screen.getAllByRole("img")[0]); 

    const storyViewer = screen.getByTestId("story-viewer");
    fireEvent.dblClick(storyViewer, { clientX: 300 }); 

    expect(screen.getByAltText("Story")).toBeVisible(); 
  });

  it("should move to the previous story on double-clicking left side", () => {
    render(<App />);
    fireEvent.click(screen.getAllByRole("img")[0]);

    const storyViewer = screen.getByTestId("story-viewer");
    fireEvent.dblClick(storyViewer, { clientX: 300 });
    fireEvent.dblClick(storyViewer, { clientX: 50 }); 

    expect(screen.getByAltText("Story")).toBeVisible();
  });

  it("should close the story viewer when clicking close button", () => {
    render(<App />);
    fireEvent.click(screen.getAllByRole("img")[0]);

    fireEvent.click(screen.getByRole("button", { name: /×/ }));
    expect(screen.queryByTestId("story-viewer")).not.toBeInTheDocument();
  });
});
