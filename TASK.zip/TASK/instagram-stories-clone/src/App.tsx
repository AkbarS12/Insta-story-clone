import React, { useEffect, useState } from "react";
import StoryList from "./components/StoryList";
import StoryViewer from "./components/StoryViewer";
import story1 from "./assets/story1.jpg";
import story2 from "./assets/story2.jpg";
import story3 from "./assets/story3.jpg";



const App: React.FC = () => {
  const [viewingStory, setViewingStory] = useState(false);
  const [selectedStoryIndex, setSelectedStoryIndex] = useState(0);
  const [viewedStories, setViewedStories] = useState<number[]>([]); 
  const [isMobile, setIsMobile] = useState(true);

  const handleSelectStory = (index: number) => {
    setSelectedStoryIndex(index);
    setViewingStory(true);
    setViewedStories((prev) => Array.from(new Set([...prev, index])));

  };
  useEffect(() => {
    const checkScreenSize = () => {
      setIsMobile(window.innerWidth < 768);
    };

    checkScreenSize();
    window.addEventListener("resize", checkScreenSize);
    return () => window.removeEventListener("resize", checkScreenSize);
  }, []);

  //To view only in mobile uncomment the below lines.(as of now it is for desktop)
  // if (!isMobile) {
  //   return <div className="desktop-message">This app is only available on mobile.</div>;
  // }


  return (
    <div className={`app ${viewingStory ? "story-active" : ""}`}>
      {!viewingStory ? (
        <StoryList onSelectStory={handleSelectStory} viewedStories={viewedStories} />
            ) : (
        <StoryViewer
          stories={[
            { id: 1, image: story1 },
            { id: 2, image: story2 },
            { id: 3, image:story3 },
          ]}
          initialIndex={selectedStoryIndex}
          onClose={() => setViewingStory(false)}
          setViewedStories={setViewedStories}
        />
      )}
    </div>
  );
};

export default App;
