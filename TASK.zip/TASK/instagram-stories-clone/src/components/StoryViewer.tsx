import React, { useState, useEffect } from "react";
import "../styles.css";

interface Story {
  id: number;
  image: string;
}

interface Props {
  stories: Story[];
  initialIndex: number;
  onClose: () => void;
  setViewedStories: React.Dispatch<React.SetStateAction<number[]>>;

}

const StoryViewer: React.FC<Props> = ({ stories, initialIndex, onClose, setViewedStories }) => {
  const [currentIndex, setCurrentIndex] = useState(initialIndex);

  useEffect(() => {
    setViewedStories((prev) => Array.from(new Set([...prev, currentIndex])));
  }, [currentIndex, setViewedStories]);

  useEffect(() => {
    const timer = setTimeout(() => {
      if (currentIndex < stories.length - 1) {
        setCurrentIndex(currentIndex + 1);
      } else {
        onClose();
      }
    }, 15000);
    return () => clearTimeout(timer);
  }, [currentIndex, stories.length, onClose]);

  const handleNext = () => {
    if (currentIndex < stories.length - 1) {
      setCurrentIndex(currentIndex + 1);
      setViewedStories((prev) => Array.from(new Set([...prev, currentIndex + 1]))); 
    } else {
      onClose();
    }
  };

  const handlePrev = () => {
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
    }
  };

  return (
    <div
    data-testid="story-viewer"
      className="story-viewer"
      onDoubleClick={(e) => {
        e.preventDefault();
        const { clientX, currentTarget } = e;
        const middle = currentTarget.clientWidth / 2;
  
        if (clientX > middle) {
          handleNext(); 
        } else {
          handlePrev();
        }
      }}
    >
      <button className="close-btn" onClick={onClose}>×</button>
  
      <div className="story-image-container enlarged">
        <img src={stories[currentIndex].image} alt="Story" className="story-image" draggable="false" />
      </div>
    </div>
  );
  
};

export default StoryViewer;
