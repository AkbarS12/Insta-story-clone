import React from "react";
import "../styles.css";
import story1 from "../assets/story1.jpg";
import story2 from "../assets/story2.jpg";
import story3 from "../assets/story3.jpg";

interface Story {
  id: number;
  image: string;
}

const stories: Story[] = [
  { id: 1, image: story1},
  { id: 2, image: story2 },
  { id: 3, image: story3 },
];

interface Props {
    onSelectStory: (index: number) => void;
    viewedStories: number[]; 
}

const StoryList: React.FC<Props> = ({ onSelectStory, viewedStories }) => {
    return (
    <div className="story-list-container">
      <div className="story-list">
        {stories.map((story, index) => (
          <div
            key={story.id}
            className={`story-thumbnail-container ${viewedStories.includes(index) ? "viewed" : "unviewed"}`}
            onClick={() => onSelectStory(index)}
          >
            <img src={story.image} alt={`Story ${story.id}`} className="story-thumbnail" />
          </div>
        ))}
      </div>
    </div>
  );
};

export default StoryList;
